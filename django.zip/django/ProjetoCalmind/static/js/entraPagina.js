// Função chamada quando o formulário é enviado
function irParaPagina(event) {
  event.preventDefault(); // impede o reload do form

  // Redireciona para a página
  window.location.href = "LiaIA.html";
}